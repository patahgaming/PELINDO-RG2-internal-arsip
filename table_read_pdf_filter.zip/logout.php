<?php
include "functions.php";
logout();
?>