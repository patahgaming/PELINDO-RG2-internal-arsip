<?php
include "functions.php";
echo "<script>alert('File berhasil ditambahkan.');</script>";
header("Location: admin_page.php");
exit;
